export default class Timer {

    /**@type {Phaser.Time.timer}*/
    timer

    /**@type {Phaser.Scene} scene*/
    scene

    /**@type {Phaser.GameObjects.Text} label*/
    label;

    /**@type {Function} finishedCallBack*/
    finishedCallBack;

    constructor(scene, label) {
        this.scene = scene;
        this.label = label;
    }

    duration = 0;

    startTimer(callBack, duration = 60000) {
        this.stopTimer();

        this.finishedCallBack = callBack;
        this.duration = duration;

        this.timer = this.scene.time.addEvent({
            delay: duration,
            callback: () => {

                this.label.text = 'Time left: 0';

                this.stopTimer();

                if (callBack) {
                    callBack();
                }
            }
        });
    }

    stopTimer() {

        if (this.timer) {
            this.timer.destroy();
            this.timer = undefined;
        }
    }

    uptadeTimer(score) {

        if (!this.timer || !this.duration) {
            return;
        }

        if (score.getData('up')) {
            console.log('Timer updated');
            this.duration += 5000;
            this.stopTimer(); 
        this.startTimer(this.finishedCallBack, this.duration); 
        }

        const elapsed = this.timer.getElapsed(); // tempo decorrido
        const remaining = this.duration - elapsed; // tempo restante
        const seconds = remaining / 1000;

        this.label.text = `Time left: ${seconds.toFixed(2)}`;

        score.setData('up', false);
    }
}

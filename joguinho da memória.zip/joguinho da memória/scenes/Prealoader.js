export default class Prealoader extends Phaser.Scene {
	constructor() {
		super('prealoader')
	}

	preload() {
		
		this.load.image('bear', 'assets/Animals/PNG/Square (outline)/bear.png');
		this.load.image('elephant', 'assets/Animals/PNG/Square (outline)/elephant.png');
		this.load.image('giraffe', 'assets/Animals/PNG/Square (outline)/giraffe.png');
		this.load.image('hippo', 'assets/Animals/PNG/Square (outline)/hippo.png');
		this.load.image('monkey', 'assets/Animals/PNG/Square (outline)/monkey.png');
		this.load.image('panda', 'assets/Animals/PNG/Square (outline)/panda.png');
		this.load.image('rhino', 'assets/Animals/PNG/Square (outline)/rhino.png');
		this.load.image('snake', 'assets/Animals/PNG/Square (outline)/snake.png');

		this.load.image('floor', 'assets/Sokoban/PNG/Retina/Ground/ground_04.png');
		this.load.spritesheet('sokoban', 'assets/Sokoban/Tilesheet/sokoban_tilesheet.png', 
		{ frameWidth: 64, frameHeight: 64 });
	}

	create() {

		this.floor = this.add.tileSprite(400, 300, 0, 0, 'floor').setDepth(-11);


		this.anims.create({
			key: 'down-idle',
			frames: [{ key: 'sokoban', frame: 52 }]
		});

		this.anims.create({
			key: 'down-walk',
			frames: this.anims.generateFrameNumbers('sokoban', { start: 52, end: 54 }),
			frameRate: 9,
			repeat: -1
		});

		this.anims.create({
			key: 'up-idle',
			frames: [{ key: 'sokoban', frame: 55 }]
		});

		this.anims.create({
			key: 'up-walk',
			frames: this.anims.generateFrameNumbers('sokoban', { start: 55, end: 57 }),
			frameRate: 9,
			repeat: -1
		});

		this.anims.create({
			key: 'left-idle',
			frames: [{ key: 'sokoban', frame: 81 }]
		});

		this.anims.create({
			key: 'left-walk',
			frames: this.anims.generateFrameNumbers('sokoban', { start: 81, end: 83 }),
			frameRate: 9,
			repeat: -1
		});

		this.anims.create({
			key: 'right-idle',
			frames: [{ key: 'sokoban', frame: 78 }]
		});

		this.anims.create({
			key: 'right-walk',
			frames: this.anims.generateFrameNumbers('sokoban', { start: 78, end: 80 }),
			frameRate: 9,
			repeat: -1
		});

		this.anims.create({
			key: 'stopped-idle',
			frames: [{ key: 'sokoban', frame: 52 }]
		});

		// Change scene
		this.scene.start('game');
	}
}



export default class Functions {

    constructor(scene, label) {
        console.log('Functions constructor');
        this.scene = scene;
        this.label = label;
    }

    matchCounter = 0

    createMatrix(matrix) {
        // logica para implementar a matrix que servirá de base para o jogo da memória
        let numbers = [];
        for (let a = 0; a < 8; a++) {
            numbers.push(a, a);
        }

        // para niveis com quantidades impares de caixotes baste fazer um ajuste final após a criação de numbers

        // se der errado volta de tras para frente
        for (let b = 0; b < numbers.length - 1; b++) {
            const c = Math.floor(Math.random() * (b + 1));
            [numbers[c], numbers[b]] = [numbers[b], numbers[c]];
        }

        for (let d = 0; d < 4; d++) {
            let row = [];
            for (let e = 0; e < 4; e++) {
                row.push(numbers[d * 4 + e]);
            }
            matrix.push(row);
        }

        console.log(matrix);
    }

    createBoxes(context, matrix) {
        const width = context.scale.width;
        let x = 0.2;
        let y = 100;

        for (let row = 0; row < matrix.length; row++) {
            for (let col = 0; col < matrix[row].length; col++) {

                // cria a caixa, adicionar atributos a ela setData
                const box = context.boxGroup.get(width * x, y, 'sokoban', 6);
                box.setSize(64, 48).setOffset(0, 16).setData('animals', matrix[row][col]);
                box;
                x += 0.2;
            }

            x = 0.2;
            y += 130;
        }
    }

    actionBox(player, box) {
        /*console.log('Object A:');
        - console.dir(a);
        - console.log('Object B:');
        - console.dir(b);*/
        //this is for debugging purposes

        if (box.getData('opened')) {
            console.log('Caixa já aberta');
            return;
        }

        //verifica se a caixa está ativa
        if (this.activeBox) {
            return;
        }

        this.activeBox = box;
        this.activeBox.setFrame(9);
    }

    movePlayer(player, cursors, activeBox, faunaGroup, context, score) {
        //gerencia o player

        if (!player.active) {
            return;
        }

        const speed = 200;

        if (cursors.up.isDown) {

            player.setVelocity(0, -speed);
            player.play('up-walk', true);

        } else if (cursors.down.isDown) {

            player.setVelocity(0, speed);
            player.play('down-walk', true);

        } else if (cursors.left.isDown) {

            player.setVelocity(-speed, 0);
            player.play('left-walk', true);

        } else if (cursors.right.isDown) {

            player.setVelocity(speed, 0);
            player.play('right-walk', true);

        } else {

            player.setVelocity(0, 0)

            if (player.anims.currentAnim) {
                const key = player.anims.currentAnim.key;
                const parts = key.split('-');
                const direction = parts[0];
                player.play(`${direction}-idle`);
            } else {
                player.play('stopped-idle');
            }
        }

        //"this.player.body.setVelocityX(speed);" or "this.player.body.setVelocityY(speed);"
        // this could allow diagonal movement

        const spacePressed = Phaser.Input.Keyboard.JustUp(context.cursors.space);

        if (spacePressed) {
            this.openBox(activeBox, faunaGroup, context, player, score);
        }
    }

    openBox(box, faunaGroup, context, player, score) {
        //verifica se a caixa está ativa
        if (!box || box.getData('opened')) { return; }

        const animals = box.getData('animals');

        let pet;

        switch (animals) {
            case 0:
                pet = faunaGroup.get(box.x, box.y);
                pet.setTexture('bear');
                break;
            case 1:
                pet = faunaGroup.get(box.x, box.y);
                pet.setTexture('elephant');
                break;
            case 2:
                pet = faunaGroup.get(box.x, box.y);
                pet.setTexture('giraffe');
                break;
            case 3:
                pet = faunaGroup.get(box.x, box.y);
                pet.setTexture('hippo');
                break;
            case 4:
                pet = faunaGroup.get(box.x, box.y);
                pet.setTexture('monkey');
                break;
            case 5:
                pet = faunaGroup.get(box.x, box.y);
                pet.setTexture('panda');
                break;
            case 6:
                pet = faunaGroup.get(box.x, box.y);
                pet.setTexture('rhino');
                break;
            case 7:
                pet = faunaGroup.get(box.x, box.y);
                pet.setTexture('snake');
                break;
            default:
                console.log('Animal não encontrado');
        }

        if (!pet) {
            return;
        }

        box.setData('opened', true);
        pet.setData('sorted', true);

        pet.scale = 0;
        pet.Alpha = 0;

        context.selectedBoxes.push({ box, pet });

        context.tweens.add({
            targets: pet,
            y: '-=50',
            scale: 0.45,
            alpha: 1,
            duration: 500,
            Oncomplete: () => {

                if (context.selectedBoxes.length < 2) {
                    return;
                }

                this.checkForMatch(context, player, score);
            }
        });

        context.activeBox.setFrame(8);
        context.activeBox = undefined;

    }

    manageBox(context) {
        // gerencia a profundidade das colisões do jogo
        context.children.each(child => {

            // verifica se o objeto (child) possui o atributo 'sorted'
            if (child.getData('sorted')) {
                child.setDepth(1);
                return;
            }

            if (child.getData('time')) {
                child.setDepth(2);
                return;
            }

            child.setDepth(-500 + child.y);
        });

        //gerencia a ativação da caixa
        if (!context.activeBox) {
            return;
        }

        const distance = Phaser.Math.Distance.Between(
            context.player.x, context.player.y,
            context.activeBox.x, context.activeBox.y);


        if (distance < 64) {
            return;
        }

        context.activeBox.setFrame(6);
        context.activeBox = undefined;

    }

    checkForMatch(context, player, score) {
        const second = context.selectedBoxes.pop();
        const first = context.selectedBoxes.pop();

        var x = 0;

        if (first.box.getData('animals') !== second.box.getData('animals')) {
            //if (first.pet.texture.key !== second.pet.texture.key) {

            // paralisar o player por errar a combinação
            this.stunned(player, context);

            context.tweens.add({
                targets: [first.pet, second.pet],
                y: '+=50', // desce a imagem
                scale: 0,
                alpha: 0.5, // transparência (não faz tanta diferença)
                duration: 700, // tempo de duração da animação (não faz tanta diferença)
                delay: 800, // se não tiver a segunda imagem não aparece
                onStart: () => {
                    // após a animação, antes do delay
                    first.box.setFrame(7);
                    first.pet.setTint(0xff0000);
                    second.box.setFrame(7);
                    second.pet.setTint(0xff0000);
                },
                onComplete: () => {
                    // após o delay
                    first.box.setFrame(6);
                    first.box.setData('opened', false);
                    second.box.setFrame(6);
                    second.box.setData('opened', false);
                }
            });

            return;
        }

        ++this.matchCounter;

        score.text = `Score: ${this.matchCounter}`;
        score.setData('up', true);

        if (this.matchCounter === 8) {
            const { width, height } = context.scale;

            context.countdown.stopTimer();

            const text = context.add.text(width / 2, height / 2, 'Você venceu!', {
                fontFamily: 'Galindo',
                fontSize: '48px',
                color: '#FFF900',
                fontStyle: 'normal',
                strokeThickness: 1,
                shadow: { stroke: true, fill: true, blur: 5, color: '#0E0E0E' },
                resolution: 2
            }).setOrigin(0.5);

            text.setData('time', true);
        }

        return;

    }

    stunned(player, context) {
        player.setTint(0xff0000);
        player.active = false;
        player.setVelocity(0, 0)

        context.time.delayedCall(1000, () => {
            console.log('Player is no longer stunned');
            player.setTint(0xffffff);
            player.active = true;
        });

    }

    timesOver() {
        this.player.active = false
        this.player.setVelocity(0, 0)

        const { width, height } = this.scale;
        this.add.text(width * 0.5, height * 0.5, 'You Lose!', {
            fontFamily: 'Galindo',
            fontSize: '48px',
            color: '#FFF900',
            fontStyle: 'normal',
            strokeThickness: 1,
            shadow: { stroke: true, fill: true, blur: 5, color: '#0E0E0E' },
            resolution: 2
        })
            .setOrigin(0.5).setData('time', true)
    }

}
import Prealoader from "./Prealoader.js";
import Functions from "./functions.js";
import Game from "./Game.js";

const config = {
	type: Phaser.AUTO,
	width: 800,
	height: 600,
	physics: {
		default: 'arcade',
		arcade: {
			debug: true,
			gravity: { y: 0 },
		},
	},
	scene: [Prealoader, Functions, Game]
};

const game = new Phaser.Game(config);

export default game;

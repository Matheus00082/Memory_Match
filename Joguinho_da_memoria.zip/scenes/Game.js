import Functions from './functions.js';
import Timer from './timer.js';

const myFunctions = new Functions();

const matrix = [];

export default class Game extends Phaser.Scene {
    /**@type {Phaser.Types.Input.Keyboard.CursorKeys} */
    cursors;

    /**@type {Phaser.Physics.Arcade.Sprite}*/
    player;

    /**@type {Phaser.Physics.Arcade.StaticGroup}*/
    boxGroup;

    /**@type {Phaser.Physics.Arcade.Sprite}*/
    activeBox;

    /**@type {Phaser.GameObjects.Group}*/
    faunaGroup;

    /**@type {box: Phaser.Physics.Arcade.Sprite, item: Phaser.GameObjects.Sprite}*/
    selectedBoxes = [];

    /**@type {Timer}*/
    countdown;

    /**@type {Phaser.GameObjects.TileSprite}*/
    score;

    constructor() {
        super('game')
    }

    init() {
        this.cursors = this.input.keyboard.createCursorKeys();
    }

    create() {
        myFunctions.createMatrix(matrix);

        const { width, height } = this.scale;

        const timerLabel = this.add.text((width - 200) / 2, 20, 'Time left: 0', {
            fontFamily: 'Galindo',
            fontSize: '30px',
            color: '#FFF900',
            fontStyle: 'normal',
            strokeThickness: 1,
            shadow: { stroke: true, fill: true, blur: 5, color: '#0E0E0E' },
            resolution: 2
        }).setData('time', true);

        this.countdown = new Timer(this, timerLabel);
        this.countdown.startTimer(myFunctions.timesOver.bind(this));

        this.score = this.add.text(20, 20, 'Score: 0', {
            fontFamily: 'Galindo',
            fontSize: '30px',
            color: '#FFF900',
            fontStyle: 'normal',
            strokeThickness: 1,
            shadow: { stroke: true, fill: true, blur: 5, color: '#0E0E0E' },
            resolution: 2
        }).setData('time', true);

        this.floor = this.add.tileSprite(0, 0, width, height, "floor").setOrigin(0, 0);

        this.player = this.physics.add.sprite(width / 2, height / 2, 'sokoban')
            .setSize(40, 16).setOffset(12, 38);

        this.boxGroup = this.physics.add.staticGroup();
        myFunctions.createBoxes(this, matrix);

        this.faunaGroup = this.add.group();

        this.physics.add.collider(this.player, this.boxGroup, myFunctions.actionBox, null, this);
        this.player.setCollideWorldBounds(true);
    }

    update() {

        myFunctions.movePlayer(this.player, this.cursors, this.activeBox, this.faunaGroup, this, this.score);

        myFunctions.manageBox(this);

        this.countdown.uptadeTimer(this.score);
    }

}